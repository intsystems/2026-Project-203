# CNN2 heterogeneous experiments

CIFAR-10; Dirichlet concentration 0.1; 11 clients; full participation; 2000 rounds; 3 x 64 gradient accumulation at the broadcast model; cosine schedule.

Transfer runs the full article family using homogeneous validation-selected LRs. Tuned selects LR only by the last-five validation accuracy, averaged over tuning seeds. Momentum stays 0.9 in both experiments. The validation split holds out 5,000 images; finals retrain on all 50,000. Auxiliary AdamW LR stays 0.001. Client objectives have equal weight.

Final seeds: [0, 1, 2, 3, 4]; tuning seeds: [0]. The run seed also seeds the client partition; methods share initialization and partition at each seed. Reported accuracy is the mean +/- sample SD over seeds of each run's last-five test mean.

| Experiment | Tuning part | Method | LR | Momentum | Seeds | Test accuracy (%) |
| :-- | :-- | :-- | --: | --: | --: | --: |
| transfer |  | signmuon | 0.1 | 0.9 | 5/5 | 35.92 +/- 8.49 |
| transfer |  | ef21muonusign | 0.01 | 0.9 | 5/5 | 82.99 +/- 0.46 |
| transfer |  | ef21muonsign | 0.05 | 0.9 | 5/5 | 83.23 +/- 0.36 |
| transfer |  | ef21signmuon | 0.02 | 0.9 | 5/5 | 45.46 +/- 7.66 |
| transfer |  | muon | 0.1 | 0.9 | 5/5 | 46.02 +/- 8.55 |
| transfer |  | muonusign | 0.05 | 0.9 | 5/5 | 26.21 +/- 2.75 |
| transfer |  | muonsign | 0.02 | 0.9 | 5/5 | 25.63 +/- 3.98 |
| transfer |  | signsgd | 0.01 | 0.9 | 5/5 | 26.42 +/- 3.23 |
| transfer |  | sgd | 0.05 | 0.9 | 5/5 | 81.03 +/- 0.62 |
| transfer |  | adam | 0.001 | 0.9 | 5/5 | 71.17 +/- 7.16 |
| tuned | priority | signmuon | 0.005 | 0.9 | 5/5 | 42.96 +/- 5.94 |
| tuned | priority | ef21muonusign | 0.02 | 0.9 | 5/5 | 83.84 +/- 0.32 |
| tuned | priority | ef21muonsign | 0.02 | 0.9 | 5/5 | 84.03 +/- 0.52 |
| tuned | priority | ef21signmuon | 0.2 | 0.9 | 5/5 | 49.73 +/- 6.69 |
| tuned | priority | muon | 0.1 | 0.9 | 5/5 | 46.02 +/- 8.55 |
| tuned | remaining | muonusign | 0.001 | 0.9 | 5/5 | 44.23 +/- 3.28 |
| tuned | remaining | muonsign | 5e-05 | 0.9 | 5/5 | 40.75 +/- 0.98 |
| tuned | remaining | signsgd | 0.0005 | 0.9 | 5/5 | 36.24 +/- 4.64 |
| tuned | remaining | sgd | 0.1 | 0.9 | 5/5 | 79.71 +/- 2.03 |
| tuned | remaining | adam | 0.0005 | 0.9 | 5/5 | 75.16 +/- 1.07 |

## Search

Homogeneous 1-2-5 lattice: 5 initial points, at most 3 boundary extensions of 2 points; fixed momentum 0.9. Initial search centers match the homogeneous CNN2 experiment. Base searches receive the same search rule, seeds, and horizon. Each method's full grid finishes before validation selection; test accuracy never enters selection. Identical final configurations are reused across experiments.

Priority tuning: signmuon, ef21muonusign, ef21muonsign, ef21signmuon, muon.

Remaining tuning: muonusign, muonsign, signsgd, sgd, adam.

Tuning parts started: priority, remaining. Pending rows identify methods whose tuning or final seeds are unfinished.

- signmuon: grid [0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1]; extensions 1; search complete.
- ef21muonusign: grid [0.005, 0.01, 0.02, 0.05, 0.1]; extensions 0; search complete.
- ef21muonsign: grid [0.01, 0.02, 0.05, 0.1, 0.2]; extensions 0; search complete.
- ef21signmuon: grid [0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.5]; extensions 1; search complete.
- muon: grid [0.01, 0.02, 0.05, 0.1, 0.2]; extensions 0; search complete.
- muonusign: grid [0.0005, 0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1, 0.2]; extensions 2; search complete.
- muonsign: grid [1e-05, 2e-05, 5e-05, 0.0001, 0.0002, 0.0005, 0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1]; extensions 4; search complete.
  Additional refinement: continue past the base extension budget until an interior validation winner; 1 extra extensions; complete. Previous selected LR: 5e-05.
- signsgd: grid [0.0002, 0.0005, 0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1]; extensions 2; search complete.
- sgd: grid [0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.5]; extensions 1; search complete.
- adam: grid [0.0002, 0.0005, 0.001, 0.002, 0.005]; extensions 0; search complete.

Files: table.csv (final results), tuning.csv (validation trials), runs.csv, state.json, raw/federated/.../metrics.json (full configs and curves), and per-job logs. The archive excludes weights.
