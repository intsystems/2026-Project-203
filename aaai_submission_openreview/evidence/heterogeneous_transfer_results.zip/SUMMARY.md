# CNN2 heterogeneous experiments

CIFAR-10; Dirichlet concentration 0.1; 11 clients; full participation; 2000 rounds; 3 x 64 gradient accumulation at the broadcast model; cosine schedule.

Transfer runs the full article family using homogeneous validation-selected LRs. Tuned selects LR only by the last-five validation accuracy, averaged over tuning seeds. Momentum stays 0.9 in both experiments. The validation split holds out 5,000 images; finals retrain on all 50,000. Auxiliary AdamW LR stays 0.001. Client objectives have equal weight.

Final seeds: [0, 1, 2, 3, 4]; tuning seeds: [0]. The run seed also seeds the client partition; methods share initialization and partition at each seed. Reported accuracy is the mean +/- sample SD over seeds of each run's last-five test mean.

| Experiment | Tuning part | Method | LR | Momentum | Seeds | Test accuracy (%) |
| :-- | :-- | :-- | --: | --: | --: | --: |
| transfer |  | signmuon | 0.1 | 0.9 | 5/5 | 35.92 +/- 8.49 |
| transfer |  | ef21muonusign | 0.01 | 0.9 | 5/5 | 82.99 +/- 0.46 |
| transfer |  | ef21muonsign | 0.05 | 0.9 | 5/5 | 83.23 +/- 0.36 |
| transfer |  | ef21signmuon | 0.02 | 0.9 | 5/5 | 45.46 +/- 7.66 |
| transfer |  | muon | 0.1 | 0.9 | 5/5 | 46.02 +/- 8.55 |
| transfer |  | muonusign | 0.05 | 0.9 | 5/5 | 26.21 +/- 2.75 |
| transfer |  | muonsign | 0.02 | 0.9 | 5/5 | 25.63 +/- 3.98 |
| transfer |  | signsgd | 0.01 | 0.9 | 5/5 | 26.42 +/- 3.23 |
| transfer |  | sgd | 0.05 | 0.9 | 5/5 | 81.03 +/- 0.62 |
| transfer |  | adam | 0.001 | 0.9 | 5/5 | 71.17 +/- 7.16 |

## Search

LR factors relative to each homogeneous optimum: [0.1, 0.3, 1, 3, 10]; fixed momentum 0.9. Every method receives the same grid size, seeds, and horizon. Each method's full grid finishes before validation selection; test accuracy never enters selection. Identical final configurations are reused across experiments.

Priority tuning: signmuon, ef21muonusign, ef21muonsign, ef21signmuon, muon.

Remaining tuning: muonusign, muonsign, signsgd, sgd, adam.

Tuning parts started: none. Pending rows identify methods whose tuning or final seeds are unfinished.


Files: table.csv (final results), tuning.csv (validation trials), runs.csv, state.json, raw/federated/.../metrics.json (full configs and curves), and per-job logs. The archive excludes weights.
