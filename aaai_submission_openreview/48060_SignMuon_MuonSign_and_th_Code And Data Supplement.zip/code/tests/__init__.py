"""CPU-only test suite."""
